package com.octopepper.mediapickerinstagram.components.gallery;

import java.io.File;

interface MediaItemViewListener {
    void onClickItem(File file);
}
