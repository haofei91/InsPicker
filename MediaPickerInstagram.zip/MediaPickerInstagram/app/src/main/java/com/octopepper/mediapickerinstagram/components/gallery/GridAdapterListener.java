package com.octopepper.mediapickerinstagram.components.gallery;

import java.io.File;

interface GridAdapterListener {

    void onClickMediaItem(File file);

}
