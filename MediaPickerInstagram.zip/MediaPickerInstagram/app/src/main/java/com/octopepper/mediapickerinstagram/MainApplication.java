package com.octopepper.mediapickerinstagram;

import android.app.Application;

public class MainApplication extends Application {

}
