package com.octopepper.mediapickerinstagram.commons.models.enums;

/*
 * Created by Guillaume on 17/11/2016.
 */

public enum SourceType {

    Gallery(),
    Photo(),
    Video();

    SourceType() {}

}
