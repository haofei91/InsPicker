package com.octopepper.mediapickerinstagram.components.editor;

import android.support.v7.app.AppCompatActivity;

public class EditorActivity extends AppCompatActivity {

}
