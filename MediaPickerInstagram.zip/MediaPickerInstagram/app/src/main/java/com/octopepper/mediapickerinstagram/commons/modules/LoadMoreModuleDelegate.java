package com.octopepper.mediapickerinstagram.commons.modules;

public interface LoadMoreModuleDelegate {
    void shouldLoadMore();
}
