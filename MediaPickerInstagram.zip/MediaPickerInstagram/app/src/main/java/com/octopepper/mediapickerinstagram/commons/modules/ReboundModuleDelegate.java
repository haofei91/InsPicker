package com.octopepper.mediapickerinstagram.commons.modules;

public interface ReboundModuleDelegate {
    void onTouchActionUp();
}
